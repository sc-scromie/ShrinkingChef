DesignModo Free Social Bookmarks/Networking Icons Set
�DesignModo Social Bookmarks/Networking� is an icons set consisting of 60 individual icons of the popular social networks/Web 2.0 sites out there.  The set consists of 60 high quality icons in 32-bit transparency PNG format (64 x 64, 48 x 48, 32 x 32). They are free to use non-commercially. Put them on your blog or on your website to help users bookmark or share your site socially. You may share them only providing link to DesignModo.com.

DesignModo Free Social Bookmarks/Networking Icons Set is licensed under a Creative Commons Attribution-Share Alike 3.0 Unported License (http://creativecommons.org/licenses/by-nc-sa/3.0/). 

You are allowed to use these icons anywhere you want, however we�ll highly appreciate if you will link to our website when you share them - http://designmodo.com

Thanks for supporting our website and enjoy!

Links:
http://designmodo.com
http://rockablethemes.com