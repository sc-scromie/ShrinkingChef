Free Icon Set: Yammy Social Media Icon Set
Designed by Helen Gizi - http://www.pinkmoustache.net/ and released exclusively for Onextrapixel.com and its readers.

Thank you for downloading this set of freebie.

This freebie is brought to you by Onextrapixel.com

Feel free to use them for personal or commercial projects. However, these icons may not be sold, rented, sub-licensed, transferred, edited, altered, or otherwise. The icons may not be offered for free downloading from websites other than Onextrapixel.com. If you�d like to share this set of icons, help us spread the word by linking back to this original release. Thank you.

Onextrapixel Team,
http://www.onextrapixel.com
